#!/bin/bash

g++ -fopenmp run4.cpp -o a3

OUTPUT_FILE="run4.txt"

for((i=1;i<=20;i++)); do
    timeTaken=$(./a3 $i 2 | grep "Time:" | awk '{print $2}')
    echo $i  $timeTaken 
    echo $i,$timeTaken >> OUTPUT_FILE
done