#!/bin/bash

g++ -fopenmp run3.cpp -o a2

OUTPUT_FILE="run2.txt"
for((i=1;i<=8;i++)); do
    timeTaken=$(./a2 $i | grep "Time:" | awk '{print $2}')
    echo $i  $timeTaken # for debug
    echo $i,$timeTaken >> $OUTPUT_FILE
done
