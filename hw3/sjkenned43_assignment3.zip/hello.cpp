#include <iostream>
int main()
{
	std::cout << "Goodbye cruel world" << std::endl;
	return 0;
}
	//hello
	
