#!/bin/bash

# first compile 
g++ run2.cpp -o a1

OUTPUT_FILE="run2.txt"
for ((i=20000; i<=40000; i+=1000)); do #use arithmetic expansion cause C style is easier to work with
    totalTime=0
    for ((j=0; j<20; j++)); do
        timeTaken=$(./a1 $i | grep "Time:" | awk '{print $2}')
        totalTime=$(echo "$totalTime + $timeTaken" | bc) # Total compiled time for this array size plus the time taken for this run (x/20)
    done
    avgTime=$(echo "scale=5; $totalTime / 20" | bc)
    echo $i  $avgTime # for debug
    echo $i  $avgTime >> $OUTPUT_FILE
done